Installation and What you should do:
- put the files somewhere in your website (f.i. var/www);
- edit includes/config.inc.php to your needs;
- make sure you shield things with a .htaccess file (Require valid-user)!


History:
v.1.1.9 Input validation
v.1.1.8 SQLite3 support
v.1.1.7 PHP code: mysqli functions replace deprecated mysql functions.
v.1.1.6 PHP code now compatible with PHP 5.4.xx.
v.1.1.5 Bugfix: optin-optout did not show tables when using postgresql.
v.1.1.4 Explanation of optin-optout improved.
v.1.1.3 HTML code now tidy and W3C markup valid.
v.1.1.2 Option included to suppress milliseconds in dates to avoid line breaks in lists.
v.1.1.1 PHP code cleaned (no more Undefined Variable and Undefined Index errors).
v.1.1.0 Multiple delete, forget and whitelisting (by checkboxes).
        More sophisticated routines for adding, deleting etc. (inline reporting
        instead of reports on separate pages).
v.1.0.1 Added missing main.css (sorry).
v.1.0.0 Improved interface by Jan Ceulen (menubar, nice table layout).
v.0.8   Last stable version by Folkert van Heusden.

Good luck!

For any questions and/or suggestions, contact folkert@vanheusden.com or jan@beebeec.nl
Consider using PGP (Folkert's key-ID is 0x1f28d8ae).
