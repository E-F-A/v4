<?php

/***************************************************
SQLgrey Web Interface
Filename:	copyright.inc.php
Purpose: 	Inserting copyright notice
Version: 	1.1.8

 *** Please do not alter these references! ***

****************************************************/

?>
<table width="100%" summary="footer">
	    <tr>
		<td>
			<hr />
			<font size="-1">
			<a href="http://www.vanheusden.com/sgwi/" target="_blank">SQLGrey webinterface v 1.1.8</a>
			by
			<a href="http://www.vanheusden.com/feedbackform.php?subject=SQLGrey%20webinterface" target="_blank">folkert@vanheusden.com</a>
			and Jan Ceulen | 
			<a href="http://www.beebeec.nl/sgwi/" target="_blank">BeeBeeC</a>
			</font>
			<hr />
		</td>
	    </tr>
</table>