// We use rarpch.cpp to create precompiled headers for MS Visual C++.
#include "rar.hpp"
