#define RARVER_MAJOR     5
#define RARVER_MINOR    60
#define RARVER_BETA      1
#define RARVER_DAY      11
#define RARVER_MONTH     3
#define RARVER_YEAR   2018
